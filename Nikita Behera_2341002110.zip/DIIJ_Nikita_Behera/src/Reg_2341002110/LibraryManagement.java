package Reg_2341002110;

// Import JDBC classes
import java.sql.*;

// Import Scanner class
import java.util.Scanner;

public class LibraryManagement {

    // Database URL
    static final String DB_URL =
            "jdbc:derby:LibraryDB;create=true";

    public static void main(String[] args) {

        // Try-with-resources for automatic cleanup
        try (
                Connection con =
                        DriverManager.getConnection(DB_URL);

                Scanner sc =
                        new Scanner(System.in)
        ) {

            // Create database tables
            createTables(con);

            // Infinite menu loop
            while (true) {

                System.out.println("\n===== LIBRARY MENU =====");

                System.out.println("1. Register Member");
                System.out.println("2. Add Book");
                System.out.println("3. Process Loan");
                System.out.println("4. Return Book");
                System.out.println("5. View Loans");
                System.out.println("6. Performance Test");
                System.out.println("7. Exit");

                System.out.print("Enter Choice: ");

                int choice = sc.nextInt();
                sc.nextLine();

                switch (choice) {

                    case 1:
                        registerMember(con, sc);
                        break;

                    case 2:
                        addBook(con, sc);
                        break;

                    case 3:
                        processLoan(con, sc);
                        break;

                    case 4:
                        returnBook(con, sc);
                        break;

                    case 5:
                        viewLoans(con);
                        break;

                    case 6:
                        performanceTest(con);
                        break;

                    case 7:
                        shutdownDatabase();
                        System.exit(0);

                    default:
                        System.out.println("Invalid Choice");
                }
            }

        } catch (SQLException e) {

            // Handle database errors
            e.printStackTrace();
        }
    }

    // ======================================================
    // PHASE 2: DATABASE DESIGN
    // ======================================================

    static void createTables(Connection con) {

        // Members table
        String members =
                "CREATE TABLE Members (" +
                        "MemberID INT PRIMARY KEY, " +
                        "Name VARCHAR(100), " +
                        "ActiveLoans INT DEFAULT 0)";

        // Books table
        String books =
                "CREATE TABLE Books (" +
                        "BookID INT PRIMARY KEY, " +
                        "Title VARCHAR(200), " +
                        "Author VARCHAR(100), " +
                        "Available BOOLEAN DEFAULT TRUE)";

        // Loans table
        String loans =
                "CREATE TABLE Loans (" +
                        "LoanID INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY, " +
                        "MemberID INT REFERENCES Members(MemberID), " +
                        "BookID INT REFERENCES Books(BookID), " +
                        "LoanDate DATE, " +
                        "ReturnDate DATE)";

        try (Statement st = con.createStatement()) {

            // Create Members table
            try {
                st.executeUpdate(members);
            } catch (SQLException ignored) {}

            // Create Books table
            try {
                st.executeUpdate(books);
            } catch (SQLException ignored) {}

            // Create Loans table
            try {
                st.executeUpdate(loans);
            } catch (SQLException ignored) {}

            // Create Index
            try {
                st.executeUpdate(
                        "CREATE INDEX idx_member " +
                                "ON Loans(MemberID)"
                );
            } catch (SQLException ignored) {}

            System.out.println("Tables Created");

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }

    // ======================================================
    // PHASE 3: APPLICATION DEVELOPMENT
    // ======================================================

    // Register Member
    static void registerMember(Connection con, Scanner sc) {

        System.out.print("Enter Member ID: ");
        int id = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Member Name: ");
        String name = sc.nextLine();

        String sql =
                "INSERT INTO Members VALUES (?, ?, 0)";

        try (
                PreparedStatement ps =
                        con.prepareStatement(sql)
        ) {

            // Set values
            ps.setInt(1, id);
            ps.setString(2, name);

            // Execute insert
            ps.executeUpdate();

            System.out.println("Member Added");

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }

    // Add Book
    static void addBook(Connection con, Scanner sc) {

        System.out.print("Enter Book ID: ");
        int id = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Title: ");
        String title = sc.nextLine();

        System.out.print("Enter Author: ");
        String author = sc.nextLine();

        String sql =
                "INSERT INTO Books VALUES (?, ?, ?, TRUE)";

        try (
                PreparedStatement ps =
                        con.prepareStatement(sql)
        ) {

            ps.setInt(1, id);
            ps.setString(2, title);
            ps.setString(3, author);

            ps.executeUpdate();

            System.out.println("Book Added");

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }

    // ======================================================
    // TRANSACTION MANAGEMENT
    // ======================================================

    static void processLoan(Connection con, Scanner sc) {

        try {

            // Disable auto commit
            con.setAutoCommit(false);

            System.out.print("Enter Member ID: ");
            int memberId = sc.nextInt();

            System.out.print("Enter Book ID: ");
            int bookId = sc.nextInt();

            // Check availability
            String checkBook =
                    "SELECT Available FROM Books " +
                            "WHERE BookID=?";

            PreparedStatement checkStmt =
                    con.prepareStatement(checkBook);

            checkStmt.setInt(1, bookId);

            ResultSet rs =
                    checkStmt.executeQuery();

            if (rs.next() && rs.getBoolean(1)) {

                // Create savepoint
                Savepoint sp =
                        con.setSavepoint();

                // Insert loan record
                String loanSql =
                        "INSERT INTO Loans " +
                                "(MemberID, BookID, LoanDate, ReturnDate) " +
                                "VALUES (?, ?, CURRENT_DATE, NULL)";

                PreparedStatement loanStmt =
                        con.prepareStatement(loanSql);

                loanStmt.setInt(1, memberId);
                loanStmt.setInt(2, bookId);

                loanStmt.executeUpdate();

                // Update book availability
                String updateBook =
                        "UPDATE Books SET Available=FALSE " +
                                "WHERE BookID=?";

                PreparedStatement bookStmt =
                        con.prepareStatement(updateBook);

                bookStmt.setInt(1, bookId);

                bookStmt.executeUpdate();

                // Update member loan count
                String updateMember =
                        "UPDATE Members " +
                                "SET ActiveLoans = ActiveLoans + 1 " +
                                "WHERE MemberID=?";

                PreparedStatement memberStmt =
                        con.prepareStatement(updateMember);

                memberStmt.setInt(1, memberId);

                memberStmt.executeUpdate();

                // Commit transaction
                con.commit();

                System.out.println("Loan Successful");

            } else {

                System.out.println("Book Not Available");

                // Rollback transaction
                con.rollback();
            }

        } catch (SQLException e) {

            try {

                // Rollback on failure
                con.rollback();

            } catch (SQLException ex) {

                ex.printStackTrace();
            }

            e.printStackTrace();

        } finally {

            try {

                // Enable auto commit again
                con.setAutoCommit(true);

            } catch (SQLException e) {

                e.printStackTrace();
            }
        }
    }

    // Return Book
    static void returnBook(Connection con, Scanner sc) {

        System.out.print("Enter Book ID: ");

        int bookId = sc.nextInt();

        try {

            // Update loan return date
            String loanUpdate =
                    "UPDATE Loans " +
                            "SET ReturnDate=CURRENT_DATE " +
                            "WHERE BookID=? " +
                            "AND ReturnDate IS NULL";

            PreparedStatement ps1 =
                    con.prepareStatement(loanUpdate);

            ps1.setInt(1, bookId);

            ps1.executeUpdate();

            // Make book available again
            String bookUpdate =
                    "UPDATE Books " +
                            "SET Available=TRUE " +
                            "WHERE BookID=?";

            PreparedStatement ps2 =
                    con.prepareStatement(bookUpdate);

            ps2.setInt(1, bookId);

            ps2.executeUpdate();

            System.out.println("Book Returned");

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }

    // View Loans
    static void viewLoans(Connection con) {

        // JOIN query to get member and book details
        String sql =
                "SELECT L.LoanID, " +
                "M.Name, " +
                "B.Title, " +
                "B.Author, " +
                "L.LoanDate, " +
                "L.ReturnDate " +
                "FROM Loans L " +
                "JOIN Members M " +
                "ON L.MemberID = M.MemberID " +
                "JOIN Books B " +
                "ON L.BookID = B.BookID";

        try (
                Statement st =
                        con.createStatement();

                ResultSet rs =
                        st.executeQuery(sql)
        ) {

            System.out.println("\n===== LOAN DETAILS =====");

            while (rs.next()) {

                System.out.println(
                        "\nLoan ID : " +
                                rs.getInt("LoanID") +

                                "\nMember Name : " +
                                rs.getString("Name") +

                                "\nBook Title : " +
                                rs.getString("Title") +

                                "\nAuthor : " +
                                rs.getString("Author") +

                                "\nLoan Date : " +
                                rs.getDate("LoanDate") +

                                "\nReturn Date : " +
                                rs.getDate("ReturnDate")
                );
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }

    // ======================================================
    // PHASE 4: PERFORMANCE EVALUATION
    // ======================================================

    static void performanceTest(Connection con) {

        try {

            long start =
                    System.nanoTime();

            Statement st =
                    con.createStatement();

            // Insert 100 test records
            for (int i = 1000; i < 1100; i++) {

                st.executeUpdate(
                        "INSERT INTO Members VALUES (" +
                                i +
                                ", 'TestUser', 0)"
                );
            }

            long end =
                    System.nanoTime();

            double ms =
                    (end - start) / 1000000.0;

            System.out.println(
                    "Execution Time: " +
                            ms + " ms"
            );

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }

    // ======================================================
    // PHASE 5: TESTING & VALIDATION
    // ======================================================

    static void shutdownDatabase() {

        try {

            DriverManager.getConnection(
                    "jdbc:derby:LibraryDB;shutdown=true"
            );

        } catch (SQLException e) {

            System.out.println(
                    "Database Shutdown Successfully"
            );
        }
    }
}